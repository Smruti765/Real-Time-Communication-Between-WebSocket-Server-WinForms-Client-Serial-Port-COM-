﻿using System.Net.WebSockets;
using System.Text;

namespace Web_socket_server_side_code
{
    public class WebSocketManager
    {
        private WebSocket _socket;
        public bool IsRunning => _socket != null && _socket.State == WebSocketState.Open;

        public async Task AcceptWebSocketAsync(HttpContext context)
        {
            if (context.WebSockets.IsWebSocketRequest)
            {
                _socket = await context.WebSockets.AcceptWebSocketAsync();
                await ReceiveLoop();
            }
            else
            {
                context.Response.StatusCode = 400;
            }
        }

        private async Task ReceiveLoop()
        {
            var buffer = new byte[1024];
            while (_socket?.State == WebSocketState.Open)
            {
                var result = await _socket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                var message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                Console.WriteLine("Received from client: " + message);
            }
        }

        public async Task SendMessageAsync(string message)
        {
            if (IsRunning)
            {
                var buffer = Encoding.UTF8.GetBytes(message);
                await _socket.SendAsync(buffer, WebSocketMessageType.Text, true, CancellationToken.None);
            }
        }

        public async Task StopAsync()
        {
            if (_socket != null)
            {
                await _socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Server stopped", CancellationToken.None);
                _socket.Dispose();
                _socket = null;
            }
        }
    }
}
