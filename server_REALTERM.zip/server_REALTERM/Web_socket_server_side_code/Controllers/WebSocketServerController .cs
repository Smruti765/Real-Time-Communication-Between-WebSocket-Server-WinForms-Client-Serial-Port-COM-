﻿using Microsoft.AspNetCore.Mvc;
using System.Net.WebSockets;
using System.Net;
using System.Text;

namespace Web_socket_server_side_code.Controllers
{
    public class WebSocketServerController : Controller
    {
        private static HttpListener _listener;
        private static List<WebSocket> _connectedClients = new List<WebSocket>();
        private static bool _isRunning = false;
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult StartServer()
        {
            if (!_isRunning)
            {
                _isRunning = true;
                _listener = new HttpListener();
                _listener.Prefixes.Add("http://localhost:8080/ws/");
                _listener.Start();

                Task.Run(() => AcceptWebSocketClients());
            }
            return RedirectToAction("Index");
        }

        private async Task AcceptWebSocketClients()
        {
            while (_isRunning)
            {
                var context = await _listener.GetContextAsync();
                if (context.Request.IsWebSocketRequest)
                {
                    var wsContext = await context.AcceptWebSocketAsync(null);
                    var socket = wsContext.WebSocket;
                    _connectedClients.Add(socket);

                    _ = Task.Run(() => ReceiveMessages(socket));
                }
                else
                {
                    context.Response.StatusCode = 400;
                    context.Response.Close();
                }
            }
        }

        private async Task ReceiveMessages(WebSocket socket)
        {
            var buffer = new byte[1024];
            while (socket.State == WebSocketState.Open)
            {
                var result = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                if (result.MessageType == WebSocketMessageType.Close)
                {
                    await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed", CancellationToken.None);
                    _connectedClients.Remove(socket);
                }
            }
        }

        [HttpPost]
        public async Task<IActionResult> SendMessage(string message)
        {
            if (!_isRunning) return RedirectToAction("Index");

            var buffer = Encoding.UTF8.GetBytes(message);
            var segment = new ArraySegment<byte>(buffer);

            foreach (var client in _connectedClients)
            {
                if (client.State == WebSocketState.Open)
                {
                    await client.SendAsync(segment, WebSocketMessageType.Text, true, CancellationToken.None);
                }
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Disconnect()
        {
            _isRunning = false;

            foreach (var client in _connectedClients)
            {
                if (client.State == WebSocketState.Open)
                {
                    client.CloseAsync(WebSocketCloseStatus.NormalClosure, "Server Stopped", CancellationToken.None).Wait();
                }
            }

            _connectedClients.Clear();
            _listener?.Stop();
            _listener = null;

            return RedirectToAction("Index");
        }

    }
}

