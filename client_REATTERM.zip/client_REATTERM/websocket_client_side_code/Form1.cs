﻿using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.WebSockets;
using System.IO.Ports;

namespace websocket_client_side_code
{
    public partial class Form1 : Form
    {
        private ClientWebSocket _client;
        private CancellationTokenSource _cts;
        private SerialPort serialPort;

        public Form1()
        {
            InitializeComponent();
            LoadAvailableComPorts();
            LoadBaudRates();
        }

        private async void btn_connect_Click(object sender, EventArgs e)
        {
            try
            {
                _client = new ClientWebSocket();
                _cts = new CancellationTokenSource();

                await _client.ConnectAsync(new Uri("ws://localhost:8080/ws/"), _cts.Token);
                AppendMessage("✅ Connected to WebSocket server.");

                _ = Task.Run(() => ReceiveMessagesAsync());
            }
            catch (Exception ex)
            {
                AppendMessage("❌ WebSocket Connection failed: " + ex.Message);
            }
        }

        private async Task ReceiveMessagesAsync()
        {
            var buffer = new byte[1024];

            while (_client.State == WebSocketState.Open)
            {
                var result = await _client.ReceiveAsync(new ArraySegment<byte>(buffer), _cts.Token);

                if (result.MessageType == WebSocketMessageType.Close)
                {
                    await _client.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed by client", _cts.Token);
                    AppendMessage("🔌 Disconnected from WebSocket server.");
                }
                else
                {
                    var message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    AppendMessage("📥 From WebSocket: " + message);

                    // Send to SerialPort if connected
                    if (serialPort != null && serialPort.IsOpen)
                    {
                        serialPort.WriteLine(message);
                    }
                }
            }
        }

        private void LoadAvailableComPorts()
        {
            CB_comport.Items.Clear();
            CB_comport.Items.AddRange(SerialPort.GetPortNames());

            if (CB_comport.Items.Count > 0)
                CB_comport.SelectedIndex = 0;
            else
                CB_comport.Items.Add("No COM ports");
        }

        private void LoadBaudRates()
        {
            CB_Baud.Items.Clear();
            CB_Baud.Items.AddRange(new string[] { "9600", "19200", "38400", "57600", "115200" });
            CB_Baud.SelectedIndex = 0;
        }

        private void btn_connect_port_Click(object sender, EventArgs e)
        {
            try
            {
                if (serialPort == null || !serialPort.IsOpen)
                {
                    string port = CB_comport.SelectedItem.ToString();
                    int baud = int.Parse(CB_Baud.SelectedItem.ToString());

                    serialPort = new SerialPort(port, baud);
                    serialPort.DataReceived += SerialPort_DataReceived;
                    serialPort.Open();

                    AppendMessage("✅ Serial Port Connected: " + port + " @ " + baud);
                    CB_comport.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Serial Port Connection Error: " + ex.Message);
            }
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
{
    try
    {
        // Read the incoming data as a string (raw data)
        string data = serialPort.ReadExisting();  // Read data directly from the serial port

        // Display the original message received from RealTerm
        AppendMessage("📥 From Serial: " + data);

        // Optionally convert to Hex to debug non-printable characters
        //string hexData = ConvertToHex(data);
        //AppendMessage("📥 Hex Data: " + hexData);
                //
        // Send the data to WebSocket if connected
        if (_client != null && _client.State == WebSocketState.Open)
        {
            var buffer = Encoding.UTF8.GetBytes(data);
            _client.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Text, true, _cts.Token);
        }
    }
    catch (Exception ex)
    {
        AppendMessage("❌ Serial Read Error: " + ex.Message);
    }
}

// Convert the received string data to a hexadecimal string
private string ConvertToHex(string data)
{
    StringBuilder hex = new StringBuilder();
    foreach (char c in data)
    {
        hex.AppendFormat("{0:X2} ", (int)c);
    }
    return hex.ToString().Trim();
}





        private void AppendMessage(string message)
        {
            if (rtb_display_message.InvokeRequired)
            {
                rtb_display_message.Invoke(new Action(() =>
                {
                    rtb_display_message.AppendText(message + Environment.NewLine);
                }));
            }
            else
            {
                rtb_display_message.AppendText(message + Environment.NewLine);
            }
        }

        private void btn_snd_Click(object sender, EventArgs e)
        {
            try
            {
                if (serialPort != null && serialPort.IsOpen)
                {
                    serialPort.WriteLine("Test");
                    AppendMessage("📤 Sent to Serial: Test");
                }
                else
                {
                    MessageBox.Show("⚠️ Serial port not connected.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Error: " + ex.Message);
            }
        }

        private void btn_Disconnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (serialPort != null && serialPort.IsOpen)
                {
                    serialPort.DataReceived -= SerialPort_DataReceived;
                    serialPort.Close();
                    CB_comport.Enabled = true;
                    AppendMessage("🔌 Disconnected from Serial Port.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Error while disconnecting: " + ex.Message);
            }
        }
    }
}
